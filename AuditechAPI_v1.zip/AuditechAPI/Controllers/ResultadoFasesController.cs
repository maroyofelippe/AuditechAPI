using Microsoft.AspNetCore.Mvc;

namespace AuditechAPI.Controllers
{

    [ApiController]
    [Route("[Controller]")]
    public class ResultadoFasesController : ControllerBase
    {

    }
}